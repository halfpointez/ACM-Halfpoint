# DAG最短路

> 所属分类: 图论 › 最短路 › 单源最短路 › 有向无环图_正负均可
> 复杂度: O(V + E)

## 适用问题
- 有向无环图上正负权均可的最短路 / 最长路 / 路径计数(拓扑序 + DP)

对于有向无环图 且不管正负 可以使用拓扑序 + dp求最短路 时间复杂度为 o(V + E)

#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
#define endl '\n'

struct Edge {
    int to, w;
};

// 返回拓扑序，如果图有环则返回空 vector
vector<int> topo_sort(int n, vector<vector<Edge>> &adj, vector<int> &in_deg) {
    vector<int> res;
    queue<int> q;
    for (int i = 1; i <= n; i++) {
        if (in_deg[i] == 0) q.push(i);
    }
    while (!q.empty()) {
        int u = q.front(); q.pop();
        res.push_back(u);
        for (auto &e : adj[u]) {
            if (--in_deg[e.to] == 0) {
                q.push(e.to);
            }
        }
    }
    if ((int)res.size() != n) return {}; // 有环
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<vector<Edge>> adj(n + 1);
    vector<int> in_deg(n + 1, 0);

    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;  // 如果无权，读 u,v 后 w=1
        adj[u].push_back({v, w});
        in_deg[v]++;
    }

    vector<int> topo = topo_sort(n, adj, in_deg);
    if (topo.empty()) {
        cout << "存在环，无法拓扑排序" << endl;
        return 0;
    }

    // 根据题目修改 DP 初始化
    vector<i64> dp(n + 1, 0);  // 示例：最长路，初始为 0，源点可设为 0
    // 如果需要每个点至少为 1，改成 vector<i64> dp(n + 1, 1);

    for (int u : topo) {
        for (auto &e : adj[u]) {
            int v = e.to, w = e.w;
            // 修改转移方程：
            // 最长路：dp[v] = max(dp[v], dp[u] + w);
            // 最短路：dp[v] = min(dp[v], dp[u] + w);
            // 路径计数：dp[v] += dp[u];
            dp[v] = max(dp[v], dp[u] + w);
        }
    }

    // 按题目要求输出
    for (int i = 1; i <= n; i++) {
        cout << dp[i] << endl;
    }

    return 0;
}

## 例题(DAG最长链)

(注: 原稿未输出答案, 仅示意拓扑序+DP)

#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
#define endl '\n'

vector<int> topo_sort(vector<vector<int>> &Node, vector<int>& in_deg) {
	vector<int> res;
	queue<int> q;
	for(int i = 1; i < Node.size(); i++) {
		if(in_deg[i] == 0) q.push(i);
	}
	while (!q.empty()) {
		int cur = q.front();
		q.pop();
		res.push_back(cur);
		for(auto &i:Node[cur]) {
			if(--in_deg[i] == 0) {
				q.push(i);
			}
		}
	}
	return res;
}

int main() {
	int n, m;
	cin >> n >> m;
	vector<vector<int>> Node(n + 1);
	vector<int> in_deg(n + 1, 0);
	for(int i = 1; i <= m; i++) {
		int u, v;
		cin >> u >> v;
		Node[u].push_back(v);
		in_deg[v]++;
	}
	vector<int> topo = topo_sort(Node, in_deg);
	vector<int> dis(n + 1, 1);
	for(auto &i:topo) {
		for(auto &j:Node[i]) {
			dis[j] = max(dis[j], dis[i] + 1);
		}
	}


}
