// banzi_ICPC网络赛版.typ
#set page(paper: "a4", margin: (x: 1.6cm, y: 1.8cm), numbering: "1", number-align: center)
#set text(font: ("New Computer Modern", "Microsoft YaHei"), size: 10.5pt)
#set par(leading: 0.8em, spacing: 0.45em)
#set list(spacing: 0.3em)
#set heading(numbering: none)

// 代码块样式: 灰底 + 边框 + 等宽字体, 与正文区分
#show raw: set text(font: ("Consolas", "Courier New", "Microsoft YaHei"), size: 9pt)
#show raw.where(block: true): it => block(
  fill: rgb("#f6f8fa"),
  stroke: 0.5pt + rgb("#d0d7de"),
  inset: 8pt,
  radius: 3pt,
  width: 100%,
  it,
)

// 标题样式: 算法标题下加分隔线, 算法之间间隔清晰
#show heading.where(level: 1): set text(size: 15pt)
#show heading.where(level: 2): set text(size: 12.5pt)
#show heading.where(level: 3): set text(size: 12pt)
#show heading.where(level: 3): it => block(below: 8pt, it + line(length: 100%, stroke: 0.6pt + rgb("#9aa4b2")))

// 目录类别标题(显式间距, 不依赖 block 折叠)
#let tcat(name) = block(spacing: 0pt)[
  #v(16pt)
  #text(weight: "bold", size: 11.5pt)[#name]
  #v(7pt)
]

// 目录树形行: 每行一个 grid, 点线列有界; 用显式 v() 控制行距
#let tbranch(level, name) = block(spacing: 0pt)[
  #v(9pt)
  #grid(
    columns: ((level - 1) * 1.4em, auto),
    column-gutter: 0em,
    [],
    [#name],
  )
]

#let tleaf(level, name, label) = block(spacing: 0pt)[
  #v(9pt)
  #grid(
    columns: ((level - 1) * 1.4em, auto, 1fr, auto),
    column-gutter: 0.25em,
    [],
    [#name],
    box(width: 1fr, repeat[.]),
    text(weight: "bold")[#context counter(page).at(label).first()],
  )
]

// ===== 封面 =====
#align(center)[
  #v(4cm)
  #text(size: 24pt)[*ACM-ICPC 个人算法模板*]
  #v(0.6cm)
  #text(size: 13pt)[算法竞赛常用代码与知识点汇总]
  #v(2.5cm)
  #text(size: 12pt)[整理人: halfpoint]
  #text(size: 12pt)[适用场景: ACM-ICPC、CCPC、蓝桥杯、牛客算法竞赛等]
  #text(size: 12pt)[代码语言: C++]
]
#pagebreak()

// ===== 目录一 · 算法直查表 =====
= 目录一 · 算法直查表
#grid(
  columns: 3,
  column-gutter: 2.2em,
  row-gutter: 0pt,
  [
  #block(spacing: 0pt, breakable: false)[
    #tcat("通用模板")
    #tleaf(1, "通用模板", <alg-tongyong>)
    #tcat("基础算法")
    #tleaf(1, "前缀和与差分", <alg-qianzhui>)
    #tleaf(1, "离散化", <alg-lisanhua>)
    #tcat("数据结构")
    #tleaf(1, "树状数组", <alg-shuzhuang>)
    #tleaf(1, "线段树", <alg-xianduanshu>)
    #tleaf(1, "ST表", <alg-st>)
    #tleaf(1, "单调队列", <alg-dandiao-duilie>)
    #tleaf(1, "单调栈", <alg-dandiao-zhan>)
  ]
  ],
  [
  #block(spacing: 0pt, breakable: false)[
    #tcat("图论")
    #tleaf(1, "堆优化Dijkstra", <alg-dijkstra>)
    #tleaf(1, "Floyd", <alg-floyd>)
    #tleaf(1, "BFS", <alg-bfs>)
    #tleaf(1, "多源BFS", <alg-duoyuan-bfs>)
    #tleaf(1, "0-1BFS", <alg-01bfs>)
    #tleaf(1, "DFS", <alg-dfs>)
    #tleaf(1, "三色DFS", <alg-sanse-dfs>)
    #tleaf(1, "拓扑排序", <alg-topo>)
    #tleaf(1, "并查集", <alg-bingchaji>)
    #tleaf(1, "欧拉路径与欧拉回路", <alg-oula>)
    #tleaf(1, "Prim", <alg-prim>)
    #tleaf(1, "Kruskal", <alg-kruskal>)
    #tleaf(1, "LCA(倍增与树剖)", <alg-lca>)
    #tleaf(1, "树的遍历(前中后序)", <alg-shu-bianli>)
    #tleaf(1, "树的直径", <alg-zhijing>)
  ]
  ],
  [
  #block(spacing: 0pt, breakable: false)[
    #tcat("字符串")
    #tleaf(1, "字符串哈希", <alg-hash>)
    #tleaf(1, "KMP", <alg-kmp>)
    #tleaf(1, "Manacher", <alg-manacher>)
    #tcat("数论与数学")
    #tleaf(1, "快速幂", <alg-ksm>)
    #tleaf(1, "费马小定理与逆元", <alg-feima>)
    #tleaf(1, "矩阵快速幂", <alg-juzhen>)
    #tleaf(1, "GCD与exgcd", <alg-gcd>)
    #tleaf(1, "欧拉函数", <alg-oula-hanshu>)
    #tleaf(1, "线性筛", <alg-xianxing>)
    #tleaf(1, "线性筛因数", <alg-spf>)
    #tleaf(1, "等比数列求和", <alg-dengbi>)
    #tleaf(1, "向上取整", <alg-xiangshang>)
  ]
  ],
)

#pagebreak()

// ===== 目录二 · 问题索引树 =====
= 目录二 · 问题索引树

#tcat("基础算法")
#tbranch(1, "└── 数组预处理")
#tleaf(2, "├── 前缀和与差分", <alg-qianzhui>)
#tleaf(2, "└── 离散化", <alg-lisanhua>)

#tcat("数据结构")
#tbranch(1, "├── 单点修改\_区间查询")
#tleaf(2, "└── 树状数组", <alg-shuzhuang>)
#tbranch(1, "├── 区间修改\_区间查询")
#tleaf(2, "└── 线段树", <alg-xianduanshu>)
#tbranch(1, "├── 静态区间RMQ")
#tleaf(2, "└── ST表", <alg-st>)
#tbranch(1, "└── 单调性问题")
#tleaf(2, "├── 单调队列", <alg-dandiao-duilie>)
#tleaf(2, "└── 单调栈", <alg-dandiao-zhan>)

#tcat("图论")
#tbranch(1, "├── 最短路")
#tbranch(2, "├── 单源最短路")
#tbranch(3, "└── 所有边权都是正数")
#tleaf(4, "└── 堆优化Dijkstra", <alg-dijkstra>)
#tbranch(2, "├── 多源汇最短路")
#tleaf(3, "└── Floyd", <alg-floyd>)
#tbranch(2, "└── 无权或0-1边权最短路")
#tleaf(3, "├── BFS", <alg-bfs>)
#tleaf(3, "├── 多源BFS", <alg-duoyuan-bfs>)
#tleaf(3, "└── 0-1BFS", <alg-01bfs>)
#tbranch(1, "├── 图的遍历")
#tleaf(2, "├── DFS", <alg-dfs>)
#tleaf(2, "└── BFS", <alg-bfs>)
#tbranch(1, "├── 环问题")
#tleaf(2, "├── 三色DFS", <alg-sanse-dfs>)
#tleaf(2, "└── 拓扑排序", <alg-topo>)
#tbranch(1, "├── 为DP提供计算顺序")
#tleaf(2, "└── 拓扑排序", <alg-topo>)
#tbranch(1, "├── 连通性问题")
#tleaf(2, "└── 并查集", <alg-bingchaji>)
#tbranch(1, "├── 一笔画问题")
#tleaf(2, "└── 欧拉路径与欧拉回路", <alg-oula>)
#tbranch(1, "├── 最小生成树")
#tleaf(2, "├── Prim", <alg-prim>)
#tleaf(2, "└── Kruskal", <alg-kruskal>)
#tbranch(1, "└── 树上问题")
#tleaf(2, "├── LCA(倍增与树剖)", <alg-lca>)
#tleaf(2, "├── 树的遍历(前中后序)", <alg-shu-bianli>)
#tleaf(2, "└── 树的直径", <alg-zhijing>)

#tcat("字符串")
#tbranch(1, "├── 子串是否相等")
#tleaf(2, "└── 字符串哈希", <alg-hash>)
#tbranch(1, "├── 单模式串匹配")
#tleaf(2, "└── KMP", <alg-kmp>)
#tbranch(1, "└── 最长回文子串")
#tleaf(2, "└── Manacher", <alg-manacher>)

#tcat("数论与数学")
#tbranch(1, "├── 幂运算与逆元")
#tleaf(2, "├── 快速幂", <alg-ksm>)
#tleaf(2, "└── 费马小定理与逆元", <alg-feima>)
#tbranch(1, "├── 线性递推加速")
#tleaf(2, "└── 矩阵快速幂", <alg-juzhen>)
#tbranch(1, "├── 最大公约数\_不定方程")
#tleaf(2, "└── GCD与exgcd", <alg-gcd>)
#tbranch(1, "├── 与n互质的个数")
#tleaf(2, "└── 欧拉函数", <alg-oula-hanshu>)
#tbranch(1, "├── 筛素数")
#tleaf(2, "├── 线性筛", <alg-xianxing>)
#tleaf(2, "└── 线性筛因数", <alg-spf>)
#tbranch(1, "├── 等比数列求和")
#tleaf(2, "└── 等比数列求和", <alg-dengbi>)
#tbranch(1, "└── 整除取整技巧")
#tleaf(2, "└── 向上取整", <alg-xiangshang>)

#pagebreak()
// ===== 正文 =====

= 一、通用模板

=== 通用模板 <alg-tongyong>

_所属分类: 通用_  _复杂度: -_

*适用问题*

- 所有题目的通用竞赛头部(头文件、宏、快速IO)

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 INF = 1e18;
#define endl '\n'
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	return 0;
}
```

#pagebreak()

= 二、基础算法

== 数组预处理

=== 前缀和与差分 <alg-qianzhui>

_所属分类: 基础算法 › 数组预处理_  _复杂度: 预处理 O(n) / 区间修改 O(1) / 查询 O(1)_

*适用问题*

- 区间批量加减后单点/区间查询
- 区间和快速查询(前缀和)
- 把区间操作转化为两个单点操作

*用法*

差分数组主要用于解决区间批量修改的问题。它的核心思想是将对区间的操作转化为对两个单点（端点）的操作，从而显著降低时间复杂度。

*实现步骤*

对于差分数组有两个函数：

+ 初始化差分数组：$d_1 = a_1$，$d_i = a_i - a_(i-1)$（对于 $i > 1$）
+ 区间修改：执行 `d[L] += v; d[R + 1] -= v;`
+ 还原数组：对差分数组 $d$ 求一遍前缀和，即可得到修改后的原数组 $a$

*完整模板*

```cpp
#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n = 5;
    vector<int> a = {0, 1, 2, 3, 4, 5}; // 假设下标从1开始
    vector<int> d(n + 2, 0);

    // 1. 构造差分数组
    for (int i = 1; i <= n; i++) {
        d[i] = a[i] - a[i - 1];
    }

    // 2. 区间修改：在区间 [2, 4] 上加 10
    int L = 2, R = 4, v = 10;
    d[L] += v;
    d[R + 1] -= v;

    // 3. 还原原数组（求前缀和）
    for (int i = 1; i <= n; i++) {
        a[i] = a[i - 1] + d[i];
        cout << a[i] << " "; 
    }
    // 输出应为: 1 12 13 14 5
    
    return 0;
}
```

#pagebreak()

=== 离散化 <alg-lisanhua>

_所属分类: 基础算法 › 数组预处理_  _复杂度: O(n log n)_

*适用问题*

- 值域很大、数据稀疏时把原值映射到 \[1, m\] 连续下标(保持大小关系)
- 为树状数组/线段树等需要下标为键的场景做前置压缩

*用法*

将值域很大的稀疏数据映射到连续的 $[1, m]$ 下标，保持原大小关系不变。常用于树状数组、线段树等需要以下标为键的场景。

*实现步骤*

+ 复制原数组，排序后去重，得到有序唯一值列表
+ 遍历原数组，用 `lower_bound` 查出每个值在列表中的排名（1-based），存入映射数组
+ 原值 $<->$ 排名通过下标 `i` 对应：`a[i]` 是原值，`rnk[i]` 是排名

*完整模板*

```cpp
// 1. 排序 + 去重
vector<int> v(a + 1, a + n + 1);
sort(v.begin(), v.end());
v.erase(unique(v.begin(), v.end()), v.end());
int m = v.size(); // 离散化后的值域大小

// 2. 映射原数组为排名（1-based），树状数组/线段树可用 rnk[i] 作下标
vector<int> rnk(n + 1);
for (int i = 1; i <= n; i++) {
    rnk[i] = lower_bound(v.begin(), v.end(), a[i]) - v.begin() + 1; //映射离散化后的排名 查询排名也用这种方法
}

// 3. 排名和原值的对应关系
//    原值 a[i]        -> 排名 rnk[i]
//    排名 k 对应的原值 -> v[k - 1]
```

#pagebreak()

= 三、数据结构

== 单点修改\_区间查询

=== 树状数组 <alg-shuzhuang>

_所属分类: 数据结构 › 单点修改\_区间查询_  _复杂度: 修改 O(log n) / 查询 O(log n) / 初始化 O(n log n)(可优化到 O(n))_

*适用问题*

- 单点修改 + 区间和查询
- 一切可差分的信息(总和/总乘等)都能用树状数组维护
- 区间修改 + 单点查询(树状数组维护差分数组)

在基础的算法中 如果我们想要查找一段区间和 我们常用前缀和
pre\[n\] - pre\[m\] 这样的时间查询复杂度为o(1)
但是当需要修改一点的情况下 全部都得重新计算 在长数组中 这是不划算的

那么我们就需要一种数据结构 需要满足 1.查询时间不长 2.修改快

树状数组就刚好满足这种需要 其查询修改的时间复杂度均为logn

想要完全理解树状数组 就要从以下入手

众所周知 一个数字 如13(1101) 可以被拆成8 + 4 + 1的形式
那么对于 一段区间长为13 运用分块的思想 假设我们知道前8 中间4 最后1 的和  就可以在logn的时间内得到前13的前缀和

但是问题来了 对于一个真实的数组 如总长度13的数组 我们需要随时能够查询任意的前缀和 就必须存储每个数字需要的区间 如11(1011) 需要8 + 2 + 1
7(0111) 4 + 2 + 1

那么怎么样才能存储每个前缀和需要的长度区间呢？

我们首先发现 对于每个前缀和 如同11(1101) 我们只需要lowbit拆解二进制 成 长度为1对应数组下标1101 长度为100对应下标1100 长度为1000对应下标1000

这样子能保证每个数组下标间 只需要-lowbit 就能找到天然接壤的位置

同时对于数组从1开始到n 每次 不断添加新数下标 维护新范围 能够保证复用性和倍增
那么设计好了这样的数据结构 如何使用他呢？

如果需要修改的话 就只需要取解决会用到当前下标的

*用法*

一切可差分的信息 都能用树状数组来维护 例如 总和 总乘

树状数组能维护

*树状数组的思想*

在设计之初 数组一定要从1开始
树状数组的下标代表的是该下标维护的原数组右边界
下标的lowbit是维护的数组的长度
通过这两个信息就能知道该下标的所有信息

在查询时候 通过两个前缀和就能得到需要的差分信息
反之 在修改的时候 一直加lowbit就是一直在扩展自己的范围且不会遗漏

*复杂度*

时间 查询 修改均为logn
初始化 一般为nlogn 如果有所有信息 通过只修改自己的上一个父数组可以优化到n

*函数*

树状数组一般需要四个函数

+ `lowbit`函数 获取lowbit值
+ `update`函数 用来更新树状数组
+ `init`函数 初始化树状数组
+ `query`函数 用来查找

(以下板子均为和 查询也是区间和)

*完整模板*

```cpp
// 1.lowbit函数如下
i64 lowbit(int x) {
	return (x & -x);
}

// 2.update函数如下
void update(int x, int k) {
	for(int i = x; i <= n; i += lowbit(i)) {
		c[i] += k; //c[i]为树状数组
	}
}

// 3.init函数如下 logn版本
	for(int i = 1; i <= n; i++) {
		cin >> arr[i];
		update(i, arr[i]);
	}

// 3.init函数如下 n版本
// 1. 预装填：把 tree 变成 a 的副本（下标从 1 开始）
for (int i = 1; i <= n; i++) {
    tree[i] = a[i];
}

// 2. 线性合并
for (int i = 1; i <= n; i++) {
    int parent = i + lowbit(i);
    if (parent <= n) {
        // 将当前节点的【最终总和】直接累加给【直接父亲】
        // 这样 parent 遍历到的时候，它就已经拿到了所有下属的值
        tree[parent] += tree[i];
    }
}

// 4.query函数如下
int query(int a) {
	int sum = 0;
	for(int i = a; i >= 1; i -= lowbit(i)) {
		sum += c[i];
	}
	return sum;
}
```
#pagebreak()

== 区间修改\_区间查询

=== 线段树 <alg-xianduanshu>

_所属分类: 数据结构 › 区间修改\_区间查询_  _复杂度: 修改/查询 O(log n)_

*适用问题*

- 区间修改 + 区间查询(父范围信息能从子范围合并: 最大值/最小值/和/乘积等)

*维护的信息类型*

父范围的信息能从子范围得到 满足的如区间的 最大值 最小值 和 乘积等 不满足的如 范围上出现次数最多的数字

*功能*

范围查询 修改 时间复杂度logn

*如何判断范围修改能否在logn时间内完成*

就看在修改后能否在o(1)时间内得到修改后的信息

*线段树的思想*

首先 线段树是一个维护信息的完全二叉树
如图

线段树的构建过程是一个递归的过程
在这个过程中 存在函数f(l, r, i) 依次代表l, r 维护的区间的长度
i 存储这个区间信息的树的数组下标
递归f(l, m, 2 * i) f(m + 1, r, 2 * i + 1)就能维护线段树的左右区间并且以此放在左孩子和右孩子上

空间需要一般为4n 需要极限压缩可以为不大于 $n$ 的最大 2 的幂次（即 $2^(floor(log_2 n))$）

*代码结构*

线段树的代码一般包含三个部分

+ `bulid`函数 建立一开始的线段树
  用递归来完成
+ `query`函数 查询线段树上的信息
  用递归来完成
  每次查询三种可能
  要查询的元素在不在当前区间上，在则认为命中了 直接返回
  如果部分在区间上 分为在左边 在右边的情况 依次判断 继续递归
+ `update`函数 更新区间的信息 其中还包含up 和 down数组

*完整模板*

```cpp
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// =============================================================
// 1. 业务逻辑区：打比赛时只需修改下面这三个部分
// =============================================================

struct Tag { //懒标记
    long long add = 0; // 例子：区间加法

    Tag(long long v = 0) : add(v) {}

    // 动作叠加：旧标记如何吸收新标记 t
    void apply(const Tag &t) {
        add += t.add;
    }
};

struct Info { //信息
    long long sum = 0;
    int len = 0; // 维护区间长度，方便计算区间加

    Info() {}
    Info(long long v, int l) : sum(v), len(l) {}

    // 动作作用于结果：标记 t 如何改变当前信息
    void apply(const Tag &t) {
        sum += (long long)len * t.add;
    }
};

// 合并：两个子区间如何合并成父区间
Info operator+(const Info &a, const Info &b) {
    return {a.sum + b.sum, a.len + b.len};
}

// =============================================================
// 2. 框架区：通用的带懒标记线段树（左闭右开）
// =============================================================

template<class Info, class Tag> //模版 传入信息和懒标记
struct LazySegmentTree {
    int n;
    vector<Info> info;
    vector<Tag> tag; //初始化变量和数组

    LazySegmentTree(int n) : n(n) {
        info.assign(4 << __lg(n), Info());
        tag.assign(4 << __lg(n), Tag());
    }//初始化懒标记数组和信息数组长度

    LazySegmentTree(vector<Info> init_v) : n(init_v.size() - 1) {
        info.assign(4 << __lg(n), Info());
        tag.assign(4 << __lg(n), Tag());
        
        auto build = [&](auto &self, int p, int l, int r) -> void {
            if (r - l == 1) {
                info[p] = init_v[l];
                return;
            }
            int mid = (l + r) >> 1;
            self(self, p << 1, l, mid);
            self(self, p << 1 | 1, mid, r);
            pull(p);
        };
        build(build, 1, 1, n + 1);
    } //构造函数 传入最初的数组 

    void pull(int p) {
        info[p] = info[p << 1] + info[p << 1 | 1];
    } //向上传递信息

    void apply(int p, const Tag &v) {
        info[p].apply(v); 
        tag[p].apply(v);

    } //修改当前点的信息和懒标记信息

    void push(int p) {
        apply(p << 1, tag[p]);
        apply(p << 1 | 1, tag[p]);
        tag[p] = Tag();
    } // 向下传递信息

    void modify(int p, int l, int r, int x, const Info &v) {
        if (r - l == 1) {
            info[p] = v;
            return;
        }
        int mid = (l + r) >> 1;
        push(p);
        if (x < mid) modify(p << 1, l, mid, x, v);
        else modify(p << 1 | 1, mid, r, x, v);
        pull(p);
    }

    void rangeApply(int p, int l, int r, int x, int y, const Tag &v) {
        if (l >= y || r <= x) return;
        if (l >= x && r <= y) {
            apply(p, v);
            return;
        }
        int mid = (l + r) >> 1;
        push(p);
        rangeApply(p << 1, l, mid, x, y, v);
        rangeApply(p << 1 | 1, mid, r, x, y, v);
        pull(p);
    }

    Info rangeQuery(int p, int l, int r, int x, int y) {
        if (l >= y || r <= x) return Info();
        if (l >= x && r <= y) return info[p];
        int mid = (l + r) >> 1;
        push(p);
        // 性能优化：如果查询范围只在某一侧，不进行跨侧合并
        if (y <= mid) return rangeQuery(p << 1, l, mid, x, y);
        if (x >= mid) return rangeQuery(p << 1 | 1, mid, r, x, y);
        return rangeQuery(p << 1, l, mid, x, y) + rangeQuery(p << 1 | 1, mid, r, x, y);
    }

    // 外部调用接口（1-based）
    void modify(int p, const Info &v) { modify(1, 1, n + 1, p, v); }
    void rangeApply(int l, int r, const Tag &v) { rangeApply(1, 1, n + 1, l, r, v); }
    Info rangeQuery(int l, int r) { return rangeQuery(1, 1, n + 1, l, r); }
};

// =============================================================
// 使用示例
// =============================================================

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n = 5;
    // 准备初始数据，假设数组为 [1, 2, 3, 4, 5]
    vector<Info> a(n + 1);
    for (int i = 1; i <= n; i++) {
        a[i] = Info(i, 1); // 初始值 i，长度 1
    }

    LazySegmentTree<Info, Tag> st(a);

    // 区间 [1, 3] 加上 10 -> 注意左闭右开 rangeApply(1, 4, ...)
    st.rangeApply(1, 4, Tag(10));

    // 查询区间 [2, 4] 的和 -> rangeQuery(2, 5)
    cout << st.rangeQuery(2, 5).sum << endl;

    return 0;
}
```

#pagebreak()

== 静态区间RMQ

=== ST表(倍增) <alg-st>

_所属分类: 数据结构 › 静态区间RMQ_  _复杂度: 预处理 O(n log n) / 查询 O(1)_

*适用问题*

- 静态可重复贡献 RMQ: MAX、MIN、GCD、LCM、按位或、按位与

*核心思想*

ST表运用了倍增的思想: 先维护每个位置从 2^0 到 2^n(小于最后位置)长度中的RMQ。
例子: 数组 1 2 3 4 5 6 7 8, 查询 2-6 只需 2-4 和 4-6 合并。

```cpp
#include <bits/stdc++.h>
using i64 = long long;
using namespace std;
i64 n;
vector<i64> logN;
vector<i64> arr;
vector<vector<i64>> st; //修复: 原为 st(100, vector<i64>(100)) 硬编码

void pre() {
	logN[2] = 1;
	for(i64 i = 3; i <= n; i++) { //修复: 原为 i < n, logN[n] 未初始化
		logN[i] = logN[i / 2] + 1;
	}
}

void init() {
	st.assign(n, vector<i64>(logN[n] + 1)); //修复: 动态分配
	for(i64 i = 0; i < n; i++) st[i][0] = arr[i];
	for(i64 i = 1; i <= logN[n]; i++) {
		for(i64 j = 0; j + (1 << i) <= n; j++) {
			st[j][i] = max(st[j][i - 1], st[j + (1 << (i - 1))][i - 1]);
		}
	}
}

i64 query(i64 l, i64 r) { //0-based, l <= r
	i64 k = logN[r - l + 1]; //修复: 原为 l - r + 1, 下标为负越界
	return max(st[l][k], st[r - (1 << k) + 1][k]);
}

int main() { //修复: 原 main 只读入 n 未做任何事, 补全
	cin >> n;
	arr.resize(n + 1);
	logN.resize(n + 1);
	for(i64 i = 0; i < n; i++) cin >> arr[i];
	pre();
	init();
	i64 l, r;
	cin >> l >> r;
	cout << query(l, r) << endl;
}
```

*注意*

- 静态数据结构, 不支持修改;需要修改用线段树

#pagebreak()

== 单调性问题

=== 单调队列 <alg-dandiao-duilie>

_所属分类: 数据结构 › 单调性问题_  _复杂度: O(n)_

*适用问题*

- 滑动窗口最值(最大值/最小值)

*用法*

单调队列可用以解决滑动窗口最值问题

*实现步骤*

单调队列的本质可以分为6步

+ 从左到右遍历整个队列 
+ 每次遍历到新元素的时候分别考虑 
+ 队头是否滑出范围 是则删除到不是为止
+ 队尾是否比新来的更小或者更大 是则删除到不是为止
+ 入队新元素 
+ 此时队头就是窗口的最小值

*完整模板*

```cpp
deque<int> dq;
for (int i = 0; i < n; i++) {
    if (!dq.empty() && dq.front() < i - k + 1) dq.pop_front();
    while (!dq.empty() && a[dq.back()] >= a[i]) dq.pop_back();
    dq.push_back(i);
    if (i >= k - 1) cout << a[dq.front()] << " ";
}
```

#pagebreak()

=== 单调栈 <alg-dandiao-zhan>

_所属分类: 数据结构 › 单调性问题_  _复杂度: O(n)_

*适用问题*

- 下一个更大/更小元素
- 找左右边界、柱状图最大矩形、接雨水、子数组贡献、嵌套括号

*用法*

找左右边界、下一个大小元素、矩形 / 接雨水、子数组贡献、嵌套括号

*实现步骤*

单调栈的本质可以分为7步

+ 从左到右遍历整个队列 
+ 每次遍历到新元素的时候考虑 
+ 新元素是不是比当前的栈头更大或者更小或其他
+ 如新元素是 则弹出头到不是为止
+ 入栈新元素 
+ 此时栈头就是窗口的最小值
+ 答案数组记录下此时的位置即可

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
int main() {
    i64 n;
    cin >> n;
    vector<i64> arr(n);
    vector<i64> ans(n, 0);
    for(auto &i:arr) {
        cin >> i;
    }
    stack<i64> S;
    for(i64 i = 0; i < n; i++) {
        while (!S.empty() && arr[S.top()] < arr[i]) {
            ans[S.top()] = i + 1;
            S.pop();
        }
        S.push(i);
    }
    for(auto &i:ans) {
        cout << i << ' ';
    }
} 
```
#pagebreak()

= 四、图论

== 最短路

单源最短路

所有边权都是正数

=== 堆优化Dijkstra <alg-dijkstra>

_所属分类: 图论 › 最短路 › 单源最短路 › 所有边权都是正数_  _复杂度: O(m log n), 适合稀疏图_

*适用问题*

- 非负权图的单源最短路
- 多源最短路(超级源点技巧, 见例题)

*完整模板*

*用法*

求解非负权图单源最短路，时间复杂度 $cal(O)(m log n)$。

*实现步骤*

+ `dist[s] = 0`，其余为 INF
+ 小顶堆存 `(距离, 结点)`，起点入堆
+ 每次取出堆顶，跳过已确定的点，否则标记并松弛邻接点
+ 堆空即得起点到各点的最短路

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
int n, m, s;
vector<bool> vis;
int main() {
	cin >> n >> m >> s;
	vis.resize(n + 1, 0);
	vector<vector<pair<int, int>>> E(n + 1);
	for(int i = 1; i <= m; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		E[u].push_back({w, v});
	}
	priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
	vector<int> dis(n + 1, 1e9 + 5);
	dis[s] = 0;
	pq.push({0,s});

	while (!pq.empty()) {
		auto [d, u] = pq.top();
		pq.pop();
		if(vis[u]) continue;
		vis[u] = 1;
		for(auto [w, v]:E[u]) {
			if(dis[v] > dis[u] + w) {
				dis[v] = dis[u] + w;
				pq.push({dis[v], v});
			}
		}
	}
	for(int i = 1; i <= n; i++) {
		cout << dis[i] << ' ';
	}
	
}
```

*例题(超级源点技巧)*

值得注意的是, 可以将点权转换为一个点, 每个点都指向这个点0, 路径权就为点权。(作者原话)

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 INF = 1e18;
#define endl '\n'
int main() {
	i64 n, m;
	cin >> n >> m;
	vector<vector<pair<i64, i64>>> Node(n + 1);
	for(int i = 1; i <= m; i++) {
		i64 u, v, w;
		cin >> u >> v >> w;
		Node[u].push_back({2 * w, v});
		Node[v].push_back({2 * w, u});
	}
	for(int i = 1; i <= n; i++) {
		i64 w; cin >> w;
		Node[0].push_back({w, i});
		Node[i].push_back({w, 0});
	}

	priority_queue<pair<i64, i64>, vector<pair<i64, i64>>, greater<>> pq;
	pq.push({0, 0});
	vector<bool> vis(n + 1, 0);
	vector<i64> dis(n + 1, INF);
	dis[0] = 0;
	while (!pq.empty()) {
		auto[w, cur] = pq.top();
		pq.pop(); //修复: 原代码漏此行 -> 死循环
		if(vis[cur]) {continue;}
		vis[cur] = 1;
		for(auto [len, u]:Node[cur]) {
			if(dis[cur] + len < dis[u]) dis[u] = dis[cur] + len; //修复: 原用旧距离w
			pq.push({dis[u], u});
		}
	}
	for(int i = 1; i <= n; i++) {
		cout << dis[i] << ' ';
	}
	return 0;
}
```

*注意*

- 稠密图用朴素 Dijkstra O(n^2);有负权边不能用 Dijkstra

#pagebreak()

多源汇最短路

=== Floyd <alg-floyd>

_所属分类: 图论 › 最短路 › 多源汇最短路_  _复杂度: O(n^3)_

*适用问题*

- 任意两点间的最短路径
- 回溯任意两点的具体路径(前驱矩阵)

*核心思想*

对于一个图(任何的) 我们想知道任意两点之间的最短路径 有两种方法 

+ 对每个点djs 这样的时间复杂度是u^2*log(e) 但是有负数或者边很多的时候很亏
+ 对每个点floyd 这样时间复杂度是u ^ 3  

floyd的思想

+ 对每个点创建一个邻接矩阵 其中是他们边的距离 如果是自身 边距就是0
+ 建立一个相同大小的矩阵 前驱节点矩阵 记录当前a -> b 上 离b最近的节点 
+ 对每个节点x进行遍历 尝试若a -> b中间走 x 即a -> x -> b 会不会更短 若会更短 就更新走这条路 更新前驱节点矩阵和邻接矩阵
+ 对每个节点a -> b进行回溯 回溯到前驱节点为a为止即可

*完整模板*

```cpp
#include <bits/stdc++.h>
#define endl '\n'
using i64 = long long;
const i64 INF = 1e9;
using namespace std;
void init(const i64 &n, const i64 &m, vector<vector<i64>> &G, vector<vector<i64>> &Pre) {
	G.resize(n + 1, vector<i64>(n + 1, INF));
	Pre.resize(n + 1, vector<i64>(n + 1, -1));
	for(int i = 0; i < m; i++) {
		i64 u, v, w;
		cin >> u >> v >> w;
		G[u][v] = min(w, G[u][v]);
		G[v][u] = min(w, G[v][u]);
		Pre[u][v] = u;
		Pre[v][u] = v;
	}
	for(int i = 1; i <= n; i++) {
		G[i][i] = 0;
	}
}

void Floyd(i64 n, i64 m) { //n个点m条边
	vector<vector<i64>> G;
	vector<vector<i64>> Pre;
	init(n, m, G, Pre);
	for(int k = 1; k <= n; k++) { //k为当前尝试的前驱点
		for(int i = 1; i <= n; i++) {
			if(i == k) continue; //如果含当前点的临接矩阵 不会变化
			for(int j = 1; j <= n; j++) {
				if(j == k) continue;
				if(G[i][j] > G[i][k] + G[k][j]) {
					G[i][j] = G[i][k] + G[k][j];
					Pre[i][j] = Pre[k][j];
				}
			}
		}
	}
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			cout << G[i][j] << ' ';
		}
		cout << endl;
	}
}

vector<int> getPath(int s, int t, const vector<vector<i64>>& Pre) {
    vector<int> path;
    if (Pre[s][t] == -1) { // 不连通
        return path;
    }
    
    int cur = t;
    while (cur != s) {
        path.push_back(cur);          // 把当前节点加入路径
        cur = Pre[s][cur];            
        if (cur == -1) return {};     // 安全保护
    }
    path.push_back(s);                // 最后加入起点
    reverse(path.begin(), path.end()); // 反转得到正向路径
    return path;
}

int main() {
	int n, m;
	cin >> n >> m;
	Floyd(n, m);
	
}
```

#pagebreak()

无权或0-1边权最短路

=== BFS <alg-bfs>

_所属分类: 图论 › 最短路 › 无权或0-1边权最短路 | 图论 › 图的遍历_  _复杂度: O(n + m)_

*适用问题*

- 无权图单源最短路(首次到达即最短路)
- 层序遍历、连通块
- 多源版本见 多源BFS

*用法*

用于无权图最短路、拓扑排序、层序遍历，按层次逐层扩展，首次到达即为最短路。

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;

vector<vector<int>> G;
vector<bool> vis;
vector<int> dis;

void bfs(int s) {
    queue<int> q;
    q.push(s);
    vis[s] = true;
    dis[s] = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : G[u]) {
            if (!vis[v]) {
                vis[v] = true;
                dis[v] = dis[u] + 1;
                q.push(v);
            }
        }
    }
}
```

#pagebreak()

=== 多源BFS <alg-duoyuan-bfs>

_所属分类: 图论 › 最短路 › 无权或0-1边权最短路_  _复杂度: O(n + m)_

*适用问题*

- 无权图中每个点到最近源点的距离(多个起点)
- 多源传染/燃烧蔓延的最短时间(每层 BFS = 一个时间单位)
- 多起点到目标的最短距离(反向多源)

*核心思想*

多源BFS
本质:
你可以想象在棋盘外有一个虚拟的“超级源点”，用权值为0的边连接所有真实源点。多源BFS就是从该超级源点出发的单源BFS，保证了所有源点处于同一“起跑线”上，公平竞争最近领地。

适用问题
. 最近距离 / 最近服务点（静态图）
这是最经典的应用。给定若干个“服务点”（源点）和若干个“居民点”，求每个居民点离它最近的服务点有多远。

典型题目：LeetCode 542. 01矩阵（求每个格子到最近0的距离）、LeetCode 1162. 地图分析（求离陆地最远的海洋，本质先求最近陆地距离）。

关键逻辑：所有源点初始距离为0，同时入队，扩散时取 dist\[新\] = dist\[旧\] + 1。

2. 多源传染 / 燃烧蔓延（动态模拟）
模拟多个感染源、火源或病毒同时向四周扩散的过程，求整个图被“占领”所需的最短时间，或每个节点被“感染”的时间戳。

典型题目：LeetCode 994. 腐烂的橘子（求所有橘子腐烂的最短分钟数）。

关键逻辑：每一层BFS代表一个时间单位，队列中所有节点同步向外扩展一层，记录层数即为时间。

3. 多起点最优路径（简化状态）
当求解从“多个可能的起点”出发，到达某个终点的最短路径时，如果终点唯一，反向思维即可：把终点当作单源，反向BFS；但若起点是一大片区域（而非离散点），多源BFS能极快求出起点集合到目标的最短距离。

4. 解决“被多个障碍物影响”的问题
在地图路径规划中，如果多个障碍物（或敌人）会周期性扩张领土，多源BFS可以预先计算出每个格子被扩张势力覆盖的“危险时间”，从而帮助主角找到一条避开所有危险源的安全路径（常用于游戏AI寻路）。

多源BFS的板子很简单 只需要在正常的BFS初始队列中 一次性加入所有的源头结点即可

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 INF = 1e18;
#define endl '\n'

// 多源BFS: 无权图, 求每个点到最近源点的距离
// sources: 所有源点; dis[i] == INF 表示不可达
void multi_source_bfs(i64 n, const vector<vector<i64>> &Node, const vector<i64> &sources, vector<i64> &dis) {
	queue<i64> q;
	dis.assign(n + 1, INF);
	for(auto &s : sources) {
		dis[s] = 0;
		q.push(s);
	}
	while (!q.empty()) {
		i64 cur = q.front();
		q.pop();
		for(auto &i : Node[cur]) {
			if(dis[i] == INF) {
				dis[i] = dis[cur] + 1;
				q.push(i);
			}
		}
	}
}
```

*例题(CF 986A Fair, 原题解仅修 3 处 bug)*

n 个点每个点一种颜色(1..k), 求每个点离它最近的 s 种颜色的距离之和。

```cpp
#include <bits/stdc++.h>
#include <iostream>
#include <queue>

using i64 = long long;
const i64 INF = 1e18;
#define endl '\n';
using namespace std;

void h_BFS(i64 n, vector<vector<i64>> &Node, vector<vector<i64>> &Good, deque<i64> &q, i64 good_now) {
	vector<bool> vis(n + 1, 0);
	vector<i64> dis(n + 1, INF);
	for(auto &i:q) {
		vis[i] = 1; //修复: 原为 0, 源点应标记已访问
		dis[i] = 0;
	}

	while (!q.empty()) {
		i64 cur = q.front();
		q.pop_front(); //修复: 原为 pop_back(), 与 front() 不一致
		for(auto &i:Node[cur]) {
			if(vis[i]) continue;
			vis[i] = 1;
			dis[i] = dis[cur] + 1;
			q.push_back(i); //修复: 原代码从不入队, BFS 不扩散
		}
	}

	for(int i = 1; i <= n; i++) {
		Good[i].push_back(dis[i]);
	}

}

int main() {
	i64 n, m, k, s;
	cin >> n >> m >> k >> s;
	vector<i64> a(n + 1);
	vector<vector<i64>> Node(n + 1);
	vector<vector<i64>> Good(n + 1);
	vector<deque<i64>> q(k + 1);

	for(int i = 1; i <= n; i++){
		cin >> a[i];
		q[a[i]].push_back(i);
	}

	for(int i =1; i <= m; i++) {
		i64 u, v;
		cin >> u >> v;
		Node[u].push_back(v);
		Node[v].push_back(u);
	}

	for(int i = 1; i <= k; i++) {
		h_BFS(n ,Node, Good, q[i], i);
	}

	for(int i = 1; i <= n; i++) {
		sort(Good[i].begin(), Good[i].end());
		i64 ans = 0 ;
		for(int j = 0; j < s; j++) {
			ans += Good[i][j];
		}
		cout << ans << ' ';
	}
}
```

*注意*

- 边权全为 1 才能用 BFS;0-1 边权用 0-1BFS;正权用 Dijkstra
- 多源BFS 和多源djs 几乎写法一致, 思想也一致(作者原话)

#pagebreak()

=== 0-1 BFS <alg-01bfs>

_所属分类: 图论 › 最短路 › 无权或0-1边权最短路_  _复杂度: O(n + m)_

*适用问题*

- 边权值可能有也可能没有(一般为 0 或 1)的最短路问题

*适用范围*

边权值为可能有，也可能没有（由于 BFS 适用于权值为 1 的图，所以一般权值是 0 或 1），或者能够转化为这种边权值的最短路问题．

例如在走迷宫问题中，你可以花 1 个金币走 5 步，也可以不花金币走 1 步，这就可以用 0-1 BFS 解决．

*实现*

一般情况下，我们把没有权值的边扩展到的点放到队首，有权值的边扩展到的点放到队尾．这样即可保证像普通 BFS 一样整个队列队首到队尾权值单调不下降．

*完整模板*

```cpp
void bfs01(int s) {
	deque<int> dq;
	vector<int> dis(n + 1, INF);
	dis[s] = 0;
	dq.push_front(s);
	while (!dq.empty()) {
		int u = dq.front();
		dq.pop_front();
		for (auto [v, w] : E[u]) { // w 为 0 或 1
			if (dis[u] + w < dis[v]) {
				dis[v] = dis[u] + w;
				if (w == 0) dq.push_front(v); // 无权边放队首
				else dq.push_back(v);         // 有权边放队尾
			}
		}
	}
}
```

#pagebreak()

== 图的遍历

_BFS 见「无权或0-1边权最短路」。_

=== DFS <alg-dfs>

_所属分类: 图论 › 图的遍历_  _复杂度: O(n + m)_

*适用问题*

- 连通性判断、连通块
- 回溯搜索(排列/组合枚举)
- 有向图判环参见 三色DFS;拓扑序参见 拓扑排序

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;

vector<vector<int>> G;
vector<bool> vis;

void dfs(int u) {
    vis[u] = true;
    for (int v : G[u]) {
        if (!vis[v]) {
            dfs(v);
        }
    }
}
```

#pagebreak()

== 环问题

=== 三色DFS <alg-sanse-dfs>

_所属分类: 图论 › 环问题_  _复杂度: O(n + m)_

*适用问题*

+ 快速的判断图上是否有环
+ 给出最近找到的环的路径
+ 对每个点进行判断 判断其路径是否是安全的 即是否怎么走都不会走到环中

*核心思想*

三色dfs本质是tarjan的一个简写方式 对于有环的有向图 能快速的解决相关的简单问题 时间复杂度为o(n)

逻辑如下 在dfs的递归中 定义如下三种状态

0.该节点从未被dfs访问过

1.该节点被访问过并且在栈中 意味着该结点的子结点还在被访问中 不能下定论

2.该节点被访问且已经不在栈中 意味该结点的子结点已经全部访问完了 并且没有环的存在

如果想要记录环的路径 只需要定义一个path数组 记录当前的路径 当遇到环时 回溯path 到上一个相同的结点即可 如 path 1->2->3->2 从2回溯到上一个2就行了

需要判断是否安全 需要保证遍历了所有的结点 不要提前结束就行了 

*1.判断有没有环*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
#define endl '\n'
bool _3c_dfs(vector<vector<i64>> &Node, vector<i64> &color, i64 cur) {
	if(color[cur] == 0) color[cur] = 1;
	for(auto &i:Node[cur]) {
		i64 jud = 0;
		if(color[i] == 1) return 1;
		else if(color[i] == 0) {
			if(_3c_dfs(Node, color, i)) return 1;
		}
	}
	color[cur] = 2;
	return 0;
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	i64 n, m;
	cin >> n >> m;
	vector<vector<i64>> Node(n + 1);
	vector<i64> color(n + 1, 0); //0未访问 1在栈中 2已遍历完全
	for(int i = 1; i <= m; i++) {
		i64 u, v;
		cin >> u >> v;
		Node[u].push_back(v);
	}
	bool jud = 0;
	for(int i = 1; i <= n; i++) {
		if(color[i] == 0) jud |= _3c_dfs(Node, color, i);
	}
	cout << jud << endl;
	
}
```

*2.判断环的同时给出路径*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
#define endl '\n'
vector<i64> get_path(vector<vector<i64>> &Node, vector<i64> &color, vector<i64> &Path, i64 node) {
	vector<i64> ans;
	for(int i = Path.size() - 1; i >= 0; i--) {
		ans.push_back(Path[i]);
		if(Path[i] == node) break;
	}
	return ans;
}

bool _3c_dfs(vector<vector<i64>> &Node, vector<i64> &color, vector<i64> &Path, i64 cur, vector<i64> &ans) {
	if(color[cur] == 0) color[cur] = 1;
	Path.push_back(cur);
	for(auto &i:Node[cur]) {
		i64 jud = 0;
		if(color[i] == 1) {
			ans = get_path(Node, color, Path, i);
			return 1;
		}
		else if(color[i] == 0) {
			if(_3c_dfs(Node, color, Path, i, ans)) {
				return 1;
			};
		}
	}
	color[cur] = 2;
	Path.pop_back();
	return 0;
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	i64 n, m;
	cin >> n >> m;
	vector<vector<i64>> Node(n + 1);
	vector<i64> color(n + 1, 0); //0未访问 1在栈中 2已遍历完全
	vector<i64> Path;
	vector<i64> ans;
	for(int i = 1; i <= m; i++) {
		i64 u, v;
		cin >> u >> v;
		Node[u].push_back(v);
	}
	for(int i = 1; i <= n; i++) {
		if(color[i] == 0 && _3c_dfs(Node, color, Path, i, ans)) {
			for(auto &x:ans) cout << x << ' ';
			return 0;
		}
	}
}
```

*3.判断安全 不提前结束的写法*

```cpp
bool _3c_dfs(vector<vector<i64>> &Node, vector<i64> &color, vector<i64> &Path, i64 cur, vector<i64> &ans) {
	if(color[cur] == 0) color[cur] = 1;
	bool jud = 0;
	for(auto &i:Node[cur]) {
		if(color[i] == 2) continue;
		if(color[i] == 1) {
			jud = 1;
			continue;
		}
		if(color[i] == 0) {
			if(_3c_dfs(Node, color, Path, i, ans)) jud = 1;
		}
	}
	if(jud == 1) return 1;
	color[cur] = 2;
	return 0;
}
```

#pagebreak()

=== 拓扑排序 <alg-topo>

_所属分类: 图论 › 环问题 | 图论 › 为DP提供计算顺序_  _复杂度: O(n + m)_

*适用问题*

- 有向无环图(DAG): 得到点的先后顺序, 供线性DP/树形DP等需要前置顺序的算法使用
- 有环图: 拓扑排序后剩下的不在答案数组中的就是环上的节点
- 判环: 答案长度 \< n 说明有环

*说明*

拓扑排序 

+ 对于有向无环图 得到点的先后顺序 得到先后顺序后 可以在dp之类需要前置顺序的算法中使用
+ 对于有环图 进行拓扑排序后 剩下的不在答案数组中的就是 环上的节点

时间复杂度为O(n)

*完整模板*

```cpp
	#include <bits/stdc++.h>
	using namespace std;
	using i64 = long long;
	#define endl '\n'

	vector<i64> topo_sort(vector<i64> &In_Deg, vector<vector<i64>>	&Node, queue<i64> &q) {
		i64 n = Node.size() - 1;
		vector<i64> ans;
		for(int i = 1; i <= n; i++) {
			if(In_Deg[i] == 0) q.push(i);
		}
		while (!q.empty()) {
			i64 cur = q.front();
			q.pop();
			ans.push_back(cur);
			for(auto &i:Node[cur]) {
				In_Deg[i]--;
				if(In_Deg[i] == 0) {
					q.push(i);
				}
			}
		}
		return ans;
	}

	int main() {
		int n;
		cin >> n;
		vector<i64> ans;
		vector<i64> In_Deg(n + 1); //记录每个节点的入度
		vector<vector<i64>>	Node(n + 1); //记录每个节点的出度
		queue<i64> q; //当前入度为0的节点
		for(int i = 1; i <= n; i++) {
			while (1) {
				int cur;
				cin >> cur;
				if(cur == 0) break;
				Node[i].push_back(cur);
				In_Deg[cur]++;
			}
		}
		ans = topo_sort(In_Deg, Node, q);
		for(auto &i:ans) cout << i << ' ';
		
	}
```

#pagebreak()

== 为DP提供计算顺序

_拓扑排序见「环问题」。_

#pagebreak()

== 连通性问题

=== 并查集 <alg-bingchaji>

_所属分类: 图论 › 连通性问题_  _复杂度: 路径压缩后近似 O(1)_

*适用问题*

- 动态维护/查询集合的合并与连通性
- 无向图连通分量、Kruskal 判环

*用法*

用于动态维护和查询集合的合并与连通性，支持Find（查找根结点）和Union（合并集合）操作，路径压缩可优化查询效率至近似O(1)。

*实现步骤*

+ 存储结构：
  - 使用数组，下标表示结点，数组值表示该结点的父结点，根结点的父结点是自己
+ Find操作：
  - 普通写法：递归向上找根结点，不破坏原树结构
  - 路径压缩：递归时让路径上的每个结点直接指向根，优化后续查询
+ Union操作：找到两个元素的根结点，若不同则让一个根指向另一个根

*完整模板*

```cpp
vector<int> P;

int Find(int x) {
    if(P[x] == x) {
        return x;
    }
    return Find(P[x]);
}

int Find(int x) {
    if(P[x] == x) {
        return x;
    }
    return P[x] = Find(P[x]);
}

void Union(int x, int y) {
    int rootx = Find(x);
    int rooty = Find(y);
    if(rootx != rooty) {
        P[rootx] = rooty;
    }
}
```

#pagebreak()

== 一笔画问题

=== 欧拉路径与欧拉回路 <alg-oula>

_所属分类: 图论 › 一笔画问题_  _复杂度: O(n + m)_

*适用问题*

- 判断图是否存在欧拉路径/欧拉回路(一笔画)
- 输出一条欧拉路径/欧拉回路(Hierholzer 算法)

*8.1 判定条件*

*用法*

判断一个图是否存在欧拉路径或欧拉回路（一笔画问题）：能否从一点出发，每条边恰好经过一次（欧拉回路要求最终回到起点）。

*判定条件（图需连通/弱连通）*

- 无向图：
  - 欧拉回路：所有点的度数均为偶数
  - 欧拉路径：恰有 0 或 2 个奇度点（恰有 2 个奇度点时，它们分别是起点和终点）
- 有向图：
  - 欧拉回路：所有点 入度 = 出度
  - 欧拉路径：恰有一个点 出度 - 入度 = 1（起点），恰有一个点 入度 - 出度 = 1（终点），其余点 入度 = 出度

*8.2 Hierholzer算法*

*用法*

在 $cal(O)(n + m)$ 时间内求出一条欧拉路径/欧拉回路。

*实现步骤*

+ 选起点：欧拉回路任选一个有边的点；欧拉路径选出度 - 入度 = 1 的点（无向图选奇度点）
+ 从起点 DFS，每走过一条边就删掉这条边（无向图还要删掉反向边）
+ 走到无路可走时，将当前点压入答案
+ 答案逆序输出即为欧拉路径/回路

*完整模板（有向图）*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

vector<vector<int>> G; // 邻接表
vector<int> indeg, outdeg;
vector<int> ans;
int n, m;

bool check() { // 有向图判定：是否存在欧拉路径/回路
    int start_cnt = 0, end_cnt = 0;
    for (int i = 1; i <= n; i++) {
        if (outdeg[i] - indeg[i] == 1) start_cnt++;
        else if (indeg[i] - outdeg[i] == 1) end_cnt++;
        else if (indeg[i] != outdeg[i]) return false;
    }
    return (start_cnt == 0 && end_cnt == 0) || (start_cnt == 1 && end_cnt == 1);
}

void hierholzer(int u) {
    while (!G[u].empty()) {
        int v = G[u].back();
        G[u].pop_back();
        hierholzer(v);
    }
    ans.push_back(u); // 逆序输出 ans 即欧拉路径
}

int main() {
    cin >> n >> m;
    G.resize(n + 1);
    indeg.assign(n + 1, 0);
    outdeg.assign(n + 1, 0);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        G[u].push_back(v);
        outdeg[u]++;
        indeg[v]++;
    }
    if (!check()) {
        cout << "No" << endl;
        return 0;
    }
    int start = 1;
    for (int i = 1; i <= n; i++) {
        if (outdeg[i] - indeg[i] == 1) start = i;
    }
    hierholzer(start);
    reverse(ans.begin(), ans.end());
    for (auto &i : ans) {
        cout << i << ' ';
    }
    return 0;
}
```

*完整模板（无向图）*

```cpp
vector<vector<pair<int, int>>> G; // (邻接点, 边编号)
vector<bool> used; // 边是否被使用过
vector<int> ans;

void dfs(int u) {
    while (!G[u].empty()) {
        auto [v, eid] = G[u].back();
        G[u].pop_back();
        if (used[eid]) continue;
        used[eid] = true;
        dfs(v);
    }
    ans.push_back(u);
}
```

#pagebreak()

== 最小生成树

=== Prim <alg-prim>

_所属分类: 图论 › 最小生成树_  _复杂度: O(m log n), 适合稠密图_

*适用问题*

- 稠密图最小生成树(MST)
- 判断图是否连通(cnt == n 才成树)

*用法*

在*稠密图*中求解最小生成树，从任意结点出发，通过维护当前连通块到未连通结点的最小边权，逐步扩展连通块。时间复杂度 $cal(O)(m log n)$（优先队列实现）。

*实现步骤*

+ 初始化距离数组 `dist[]` 为无穷大，选择任意起点（如结点1），将其距离设为0
+ 使用优先队列（小顶堆）存储 `(距离, 结点)`，将起点入队
+ 用 `vis[]` 数组维护已加入最小生成树的结点
+ 每次取出队首距离最小的未访问结点，标记为已访问，累加其距离到总权值
+ 遍历该结点的所有邻接点，若邻接点未访问且当前边权小于其 `dist`，更新 `dist` 并入队

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const int INF = 0x3f3f3f3f;

vector<vector<pair<int, int>>> G;
vector<int> dist;
vector<bool> vis;

i64 prim(int n, int start = 1) {
    dist.assign(n + 1, INF);
    vis.assign(n + 1, false);
    dist[start] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
    pq.emplace(0, start);
    i64 total = 0;
    int cnt = 0;
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (vis[u]) continue;
        vis[u] = true;
        total += d;
        cnt++;
        for (auto [v, w] : G[u]) {
            if (!vis[v] && w < dist[v]) {
                dist[v] = w;
                pq.emplace(dist[v], v);
            }
        }
    }
    return cnt == n ? total : -1;
}

int main() {
    int n, m;
    cin >> n >> m;
    G.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        G[u].emplace_back(v, w);
        G[v].emplace_back(u, w);
    }
    i64 ans = prim(n);
    if (ans == -1) cout << "orz" << endl;
    else cout << ans << endl;
    return 0;
}
```

#pagebreak()

=== Kruskal <alg-kruskal>

_所属分类: 图论 › 最小生成树_  _复杂度: O(m log m), 适合稀疏图_

*适用问题*

- 稀疏图最小生成树(MST)
- 判断图是否连通

*用法*

在*稀疏图*中更优，通过将所有边按权值排序，结合并查集逐步合并连通分量，每次选择连接两个不同连通分量的最小边。时间复杂度 $cal(O)(m log m)$（主要为边排序的时间）。

*实现步骤*

+ 定义边的结构体，包含起点、终点、权值
+ 将所有边按权值从小到大排序
+ 初始化并查集，每个结点独立成一个集合
+ 遍历排序后的边，若边的两个端点不在同一连通分量，则合并它们，并累加该边权值到总权值
+ 当合并次数达到 `n-1` 时（已形成生成树），提前退出

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

struct Edge {
    int u, v, w;
    Edge(int u, int v, int w) : u(u), v(v), w(w) {}
    bool operator<(const Edge& other) const {
        return w < other.w;
    }
};

vector<Edge> edges;
vector<int> P;

int Find(int x) {
    if (P[x] != x) P[x] = Find(P[x]);
    return P[x];
}

i64 kruskal(int n) {
    sort(edges.begin(), edges.end());
    P.resize(n + 1);
    for (int i = 1; i <= n; i++) P[i] = i;
    i64 total = 0;
    int cnt = 0;
    for (auto& e : edges) {
        int rootu = Find(e.u);
        int rootv = Find(e.v);
        if (rootu != rootv) {
            P[rootu] = rootv;
            total += e.w;
            cnt++;
            if (cnt == n - 1) break;
        }
    }
    return cnt == n - 1 ? total : -1;
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.emplace_back(u, v, w);
    }
    i64 ans = kruskal(n);
    if (ans == -1) cout << "orz" << endl;
    else cout << ans << endl;
    return 0;
}
```

#pagebreak()

== 树上问题

=== LCA(最近公共祖先) <alg-lca>

_所属分类: 图论 › 树上问题_  _复杂度: 树链剖分 预处理 O(n)/查询 O(log n);倍增 预处理 O(n log n)/查询 O(log n)_

*适用问题*

- 树上两点的最近公共祖先
- 树上两点距离: dist(u,v) = dep\[u\] + dep\[v\] - 2*dep\[lca\]

*2.5.1 树链剖分*

*用法*

预处理O(n)，查询O(logn)，通过重链剖分将树划分为若干重链，快速跳转到LCA。

*实现步骤*

+ 第一个DFS（dfs1）：处理父结点father、深度deepth、子树大小size、重子结点son
+ 第二个DFS（dfs2）：创建链顶top，重子结点的链顶为父结点的链顶，轻子结点的链顶为自己
+ 寻找LCA：
  - 若二者不在同一个重链上，让链顶深度大的点跳转到他链顶的父结点
  - 直到二者在同一个重链上，深度更小的点为LCA

*完整模板*

```cpp
vector<vector<int>> G;
vector<int> fa, dep, siz, son, top;

void dfs1(int u, int f) {
  fa[u] = f, dep[u] = dep[f] + 1, siz[u] = 1;
  for (auto v : G[u]) {
    if (v == f) continue;
    dfs1(v, u);
    siz[u] += siz[v];
    if (siz[v] > siz[son[u]]) son[u] = v;
  }
}

void dfs2(int u, int f) {
    if (son[f] == u)
        top[u] = top[f];
    else
        top[u] = u;
    for (int v : G[u]) {
        if (v != f)
            dfs2(v, u);
    }
}

int LCA(int a, int b) {
    while(top[a] != top[b]) {
        if (dep[top[a]] > dep[top[b]]) a = fa[top[a]];
        else b = fa[top[b]];
    }
    return dep[a] <= dep[b] ? a : b;
}
```

*2.5.2 倍增*

*用法*

预处理O(nlogn)，查询O(logn)，利用二进制思想，通过倍增表快速跳转到祖先结点。

*实现步骤*

+ DFS：处理父亲函数fa\[0\]\[\]（2^0 = 1）和深度dep
+ 倍增表初始化：第2^k祖先是第2^(k-1)祖先的第2^(k-1)祖先
+ LCA函数：
  - 先将二者跳到同一深度
  - 若相同则直接返回
  - 否则从2^k到2^0尝试跳转，直到找到LCA

*完整模板*

```cpp
vector<vector<int>> Edge;
vector<vector<int>> fa;
vector<int> dep;
int n;

void dfs(int u, int f) {
    fa[0][u] = f;
    dep[u] = dep[f] + 1;
    for(auto &i:Edge[u]) {
        if(i != f) dfs(i, u);
    }
}

void init() {
    for(int i = 1; i <= 20; i++) {
        for(int j = 1; j <= n; j++) {
            fa[i][j] = fa[i - 1][fa[i - 1][j]];   
        }
    }
}

int LCA(int a, int b) {
    if(dep[a] < dep[b]) swap(a, b);
    for(int i = 20; i >= 0; i--) {
        if(dep[fa[i][a]] >= dep[b]) a = fa[i][a];
    }
    if(a == b) return a;
    for(int i = 20; i >= 0; i--) {
        if(fa[i][a] != fa[i][b]) {
            a = fa[i][a];
            b = fa[i][b];
        }
    }
    return fa[0][a];
}
```

#pagebreak()

=== 树的遍历(前中后序) <alg-shu-bianli>

_所属分类: 图论 › 树上问题_  _复杂度: O(n)_

*适用问题*

- 按前序(根-左-右)/中序(左-根-右)/后序(左-右-根)访问二叉树所有结点
- 用栈模拟递归(避免递归深度过大)

*2.2 前中后序遍历*

*用法*

按照不同顺序访问树的所有结点，分为前序（根-左-右）、中序（左-根-右）、后序（左-右-根），可通过递归或栈实现。

*实现步骤*

- 前序：中左右，递归序 = 1
- 中序：左中右，递归序 = 2
- 后序：左右中，递归序 = 3

递归写法：

```cpp
void 递归() {
	if(head == NULL) {
		return; //修复: 原为 break, void 函数编译错误
	}
	//输出head 前序
	递归(head.left)
	//输出head 中序
	递归(head.right)
	//输出head 后序
	
}
```

*完整模板（栈写法）*

```cpp
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

vector<int> preorderTraversal(TreeNode* root) {
    vector<int> result;
    if (!root) return result;
    stack<TreeNode*> stk;
    stk.push(root);
    while (!stk.empty()) {
        TreeNode* node = stk.top();
        stk.pop();
        result.push_back(node->val);
        if (node->right) stk.push(node->right);
        if (node->left)  stk.push(node->left);
    }
    return result;
}

vector<int> inorderTraversal(TreeNode* root) {
    vector<int> result;
    stack<TreeNode*> stk;
    TreeNode* cur = root;
    while (cur || !stk.empty()) {
        while (cur) {
            stk.push(cur);
            cur = cur->left;
        }
        cur = stk.top();
        stk.pop();
        result.push_back(cur->val);
        cur = cur->right;
    }
    return result;
}

vector<int> postorderTraversal(TreeNode* root) {
    vector<int> result;
    if (!root) return result;
    stack<TreeNode*> stk;
    TreeNode* cur = root;
    TreeNode* prev = nullptr;
    while (cur || !stk.empty()) {
        while (cur) {
            stk.push(cur);
            cur = cur->left;
        }
        cur = stk.top();
        if (!cur->right || cur->right == prev) {
            result.push_back(cur->val);
            stk.pop();
            prev = cur;
            cur = nullptr;
        } else {
            cur = cur->right;
        }
    }
    return result;
}

vector<int> postorderTraversal_reverse(TreeNode* root) {
    vector<int> result;
    if (!root) return result;
    stack<TreeNode*> stk;
    stk.push(root);
    while (!stk.empty()) {
        TreeNode* node = stk.top();
        stk.pop();
        result.push_back(node->val);
        if (node->left)  stk.push(node->left);
        if (node->right) stk.push(node->right);
    }
    reverse(result.begin(), result.end());
    return result;
}

int main() {
    TreeNode* root = new TreeNode(1);
    root->left = new TreeNode(2);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(4);
    root->left->right = new TreeNode(5);
    cout << "前序遍历: "; 
    for (int x : preorderTraversal(root)) cout << x << " ";
    cout << "\n中序遍历: ";
    for (int x : inorderTraversal(root)) cout << x << " ";
    cout << "\n后序遍历: ";
    for (int x : postorderTraversal(root)) cout << x << " ";
    return 0;
}
```

#pagebreak()

=== 树的直径 <alg-zhijing>

_所属分类: 图论 › 树上问题_

树的直径

两次BFS/DFS

树上dp
#pagebreak()

= 五、字符串

== 子串是否相等

=== 字符串哈希 <alg-hash>

_所属分类: 字符串 › 子串是否相等_  _复杂度: 预处理 O(n) / 查询 O(1)_

*适用问题*

- 快速比较区间子串是否相等
- 判断回文(正反哈希比较)

*用法*

维护字符串区间哈希值，快速比较子串是否相等、判断回文等。

- 预处理时间：$cal(O)(n)$
- 查询时间：$cal(O)(1)$

*实现步骤*

+ 生成随机基数 `base`（用 `mt19937_64` 生成，防卡哈希）
+ 预处理 `base` 的幂次数组 `power`，其中 `power[i] = base^i`
+ 预处理前缀哈希数组 `hash_pre`，其中 `hash_pre[i]` 表示前 `i` 个字符的哈希值
+ 查询区间 `[l, r]`（1-based）的哈希值：`hash_pre[r] - hash_pre[l-1] * power[r-l+1]`

*完整模板*

```cpp
#include <bits/stdc++.h>
#include <random>
#include <chrono>
using namespace std;
using i64 = long long;
using u64 = unsigned long long;

mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

const int MAXN = 1e5 + 5;
u64 base;
u64 power[MAXN];
u64 hash_pre[MAXN];

void init_hash() {
    base = rng();
    power[0] = 1;
    for (int i = 1; i < MAXN; i++) {
        power[i] = power[i-1] * base;
    }
}

void build_hash(const string &s) {
    int n = s.size();
    for (int i = 0; i < n; i++) {
        hash_pre[i+1] = hash_pre[i] * base + s[i];
    }
}

u64 get_hash(int l, int r) {
    return hash_pre[r] - hash_pre[l-1] * power[r - l + 1];
}

int main() {
    init_hash();
    string s;
    cin >> s;
    build_hash(s);
    int l = 2, r = 4;
    cout << get_hash(l, r) << endl;
    return 0;
}
```

#pagebreak()

== 单模式串匹配

=== KMP <alg-kmp>

_所属分类: 字符串 › 单模式串匹配_  _复杂度: O(n + m)_

*适用问题*

- 在主串中查找模式串的所有出现位置(单模式匹配)

*用法*

用于单模式串匹配，可在主串中快速查找模式串的所有出现位置，避免暴力匹配的回溯，时间复杂度 $cal(O)(n + m)$。

*实现步骤*

对于一串字符串 如
匹配串: abcdabxa...
模式串: abcdabcy

可以发现 abcdab是匹配的
且abcdab的最长前后缀存在为ab
因为前面都匹配 只有从c-x不匹配
所以x前的肯定是ab
那就意味着可以从c-x开始比较 而不用从头开始遍历

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
int main() {
	string s1;
	string s2;
	cin >> s1 >> s2;
	int s2_len = s2.size();
	int s1_len = s1.size();
	vector<int> next(s2_len, 0);
	int i = 0, j = 1;
	while(i < s2_len && j < s2_len) {
		while (i > 0 && s2[i] != s2[j]) {
			i = next[i - 1];
		}
		if(s2[i] == s2[j]) i++;
		next[j] = i;
		j++;
	}
	i = 0;
	j = 0;
	while (j < s1_len) {
		while(i > 0 && s2[i] != s1[j]) {
			i = next[i - 1];
		}
		if(s2[i] == s1[j]) {
			i++;
		}
		if(i == s2_len) {
			cout << j - i + 2 << endl;
			i = next[i - 1]; //修复: 回退以继续找重叠匹配
		}
		j++;
	}
	for(auto &i:next) {
		cout << i << ' ';
	}
}
```

#pagebreak()

== 最长回文子串

=== Manacher(马拉车) <alg-manacher>

_所属分类: 字符串 › 最长回文子串_  _复杂度: O(n)_

*适用问题*

- 线性时间求最长回文子串长度
- 回文半径(以每个位置为中心的最长回文)

*用法*

用于在线性时间 $cal(O)(n)$ 内求解字符串的最长回文子串长度。

*实现步骤*

+ 预处理字符串：插入 `#` 统一奇偶回文
+ 维护 `maxr`、`mid`、`ans`
+ 遍历中心，利用对称性扩展回文半径

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
string change(string &s) {
	string temp = "!#";
	for(auto &c:s) {
		temp += c;
		temp += '#';
	}
	temp += "^";
	return temp;
}

int manacher(string &s) {
	int maxr = 0, mid = 0, ans = 0;
	vector<int> p(s.size(), 0);
	for(int i = 0; i < s.size(); i++) {
		if(maxr >= i) {
			p[i] = min(p[2 * mid - i], maxr - i);
		}
		while(s[i - p[i] - 1] == s[i + p[i] + 1])
		p[i]++;
		if(i + p[i] > maxr) {
			mid = i;
			maxr = i + p[i];
		}
		ans = max(ans, p[i]);
	}
	return ans;
}

int main() {
	string s;
	cin >> s;
	s = change(s);
	cout << manacher(s);
}
```

#pagebreak()

= 六、数论与数学

== 幂运算与逆元

=== 快速幂 <alg-ksm>

_所属分类: 数论与数学 › 幂运算与逆元_  _复杂度: O(log b)_

*适用问题*

- 求 a^b mod p(指数极大)
- 矩阵快速幂/模逆元的基础

*3. 快速幂模板*

```cpp
#include <iostream>
using namespace std;
using i64 = long long;

i64 fast_pow(i64 base, i64 exponent, i64 mod) {
    i64 result = 1;
    base %= mod;
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent /= 2;
    }
    return result;
}

i64 fermat_inverse(i64 a, i64 p) {
    return fast_pow(a, p - 2, p);
}

int main() {
    i64 a, p;
    cin >> a >> p;
    cout << fermat_inverse(a, p) << endl;
    return 0;
}
```

#pagebreak()

=== 费马小定理与逆元 <alg-feima>

_所属分类: 数论与数学 › 幂运算与逆元_  _复杂度: O(log p)_

*适用问题*

- 质数模下的模逆元: a^{-1} = a^{p-2} (mod p), p 为质数且 gcd(a,p)=1

*6.1 费马小定理笔记*

*1. 定义与基本形式*

*定义*：若 $p$ 是质数，且 $gcd(a, p) = 1$，则：

$ a^(p-1) equiv 1 (mod p) $

*一般形式*：

$ a^p equiv a (mod p) $

*2. 核心应用：模逆元*

$ a^(-1) equiv a^(p-2) (mod p) $

*3. 快速幂模板*

```cpp
#include <iostream>
using namespace std;
using i64 = long long;

i64 fast_pow(i64 base, i64 exponent, i64 mod) {
    i64 result = 1;
    base %= mod;
    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exponent /= 2;
    }
    return result;
}

i64 fermat_inverse(i64 a, i64 p) {
    return fast_pow(a, p - 2, p);
}

int main() {
    i64 a, p;
    cin >> a >> p;
    cout << fermat_inverse(a, p) << endl;
    return 0;
}
```

#pagebreak()

== 线性递推加速

=== 矩阵快速幂 <alg-juzhen>

_所属分类: 数论与数学 › 线性递推加速_  _复杂度: O(m^3 log k), m 为矩阵大小_

*适用问题*

- 线性递推求第 n 项(如斐波那契)
- 图上长度为 k 的路径计数、DP 转移矩阵快速幂

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 MOD = 1e9 + 7;
#define endl '\n'
vector<vector<i64>> cacl_mat(vector<vector<i64>> &M1, vector<vector<i64>> &M2) {
	i64 m = M1.size(), n = M2[0].size(), o = M1[0].size();
	vector<vector<i64>> res(m, vector<i64>(n, 0));
	for(int i = 0; i < m; i++) {
		for(int j = 0; j < n; j++) {
			for(int k = 0; k < o; k++) {
				res[i][j] += (M1[i][k] * M2[k][j]) % MOD; 
				res[i][j] %= MOD;
			}
		}
	}
	return res;
} //矩阵乘法通用模板 

vector<vector<i64>> mat_ksm(vector<vector<i64>> M, i64 k) { // M转换矩阵 k指数 
	i64 n = M.size(); //矩阵大小
	vector<vector<i64>> res(n, vector<i64>(n));
	for(int i = 0; i < n; i++) {
		res[i][i] = 1;
	} //初始化单位矩阵
	while (k) {
		if(k & 1) {
			res = cacl_mat(res, M);
		}
		M = cacl_mat(M, M);
		k >>= 1;
	}
	return res;
}

int main() {
	i64 n; cin >> n;
	vector<vector<i64>> M = {{1, 1}, {1, 0}};
	vector<vector<i64>> ans = mat_ksm(M, n - 1);
	cout << ans[0][0];
}
```

典题

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 MOD = 998244353;
#define endl '\n'

vector<vector<vector<i64>>> Begi;

vector<vector<i64>> cacl_mat(const vector<vector<i64>> &M1, const vector<vector<i64>> &M2) {
    i64 m = M1.size(), n = M2[0].size(), o = M1[0].size();
    vector<vector<i64>> res(m, vector<i64>(n, 0));
    for(int i = 0; i < m; i++) {
        for(int k = 0; k < o ; k++) {
            if(M1[i][k] == 0) continue;
            for(int j = 0; j < n; j++) {
                res[i][j] += (M1[i][k] * M2[k][j]) % MOD; 
                res[i][j] %= MOD;
            }
        }
    }
    return res;
} //矩阵乘法通用模板 

vector<vector<i64>> mat_ksm(vector<vector<i64>> M, i64 k) { // M转换矩阵 k指数 
    i64 n = M.size(); //矩阵大小
    vector<vector<i64>> res(n, vector<i64>(n));
    for(int i = 0; i < n; i++) {
        res[i][i] = 1;
    } //初始化单位矩阵
    while (k) {
        if(k & 1) {
            res = cacl_mat(res, M);
        }
        M = cacl_mat(M, M);
        k >>= 1;
    }
    return res;
}

i64 ksm(i64 a, i64 b) {
    i64 res = 1;
    i64 base = a;
    while (b) {
        if(b & 1) {
            res *= base;
        }
        base *= base;
        b >>= 1;
    }
    return res;
}

// 新增：颜色标准化函数，将序列按第一次出现顺序映射为 0,1,2,...
vector<int> canonical(const vector<int>& a) {
    vector<int> res(a.size());
    vector<int> mp(3, -1);  // 只有三种颜色
    int cur = 0;
    for (int i = 0; i < (int)a.size(); ++i) {
        if (mp[a[i]] == -1) mp[a[i]] = cur++;
        res[i] = mp[a[i]];
    }
    return res;
}

void get(i64 n) {
    i64 MAXN = ksm(3, n);
    vector<vector<i64>> cur(1, vector<i64>(n, 0));
    for(i64 i = 0; i < MAXN; i++) {
        i64 NUM = i;
        i64 pre = 0;
        bool jud = 1;
        for(int j = 0; j < n; j++) {
            i64 dig_now = (NUM % 3);
            if(j != 0) {
                if(pre == dig_now) {
                    jud = 0;
                    break;
                }
            }
            cur[0][j] = dig_now;
            NUM /= 3;
            pre = dig_now;
        }
        
        if(jud) {
            Begi.push_back(cur);
        }
    }
}

i64 get_mat(i64 n, i64 m) {
    int s = Begi.size();  // 原始合法状态数

    // 提取颜色序列
    vector<vector<int>> states(s, vector<int>(n));
    for (int i = 0; i < s; ++i) {
        for (int k = 0; k < n; ++k) {
            states[i][k] = Begi[i][0][k];
        }
    }

    // 构建等价类
    map<vector<int>, int> id;
    int idx = 0;
    vector<int> sz;                 // 每个等价类的大小
    vector<vector<int>> repr;       // 每个等价类的代表状态

    for (int i = 0; i < s; ++i) {
        vector<int> canon = canonical(states[i]);
        if (!id.count(canon)) {
            id[canon] = idx++;
            sz.push_back(0);
            repr.push_back(states[i]);   // 第一个遇到的作为代表
        }
        sz[id[canon]]++;
    }

    int K = idx;  // 等价类数量

    // 构建带权转移矩阵
    vector<vector<i64>> trans(K, vector<i64>(K, 0));
    for (int i = 0; i < K; ++i) {
        const auto& a = repr[i];
        for (int j = 0; j < s; ++j) {
            const auto& b = states[j];
            bool ok = true;
            for (int k = 0; k < n; ++k) {
                if (a[k] == b[k]) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                int nxt = id[canonical(b)];
                trans[i][nxt] = (trans[i][nxt] + 1) % MOD;
            }
        }
    }

    if (m == 1) {
        return s % MOD;   // 第一列可以取所有原始合法状态
    }

    // 矩阵快速幂
    vector<vector<i64>> T = mat_ksm(trans, m - 1);

    // 初始向量：各等价类的大小
    vector<i64> ans(K, 0);
    for (int i = 0; i < K; ++i) {
        for (int j = 0; j < K; ++j) {
            ans[j] = (ans[j] + sz[i] * T[i][j]) % MOD;
        }
    }

    i64 res = 0;
    for (int j = 0; j < K; ++j) {
        res = (res + ans[j]) % MOD;
    }
    return res;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    get(n);
    cout << get_mat(n, m);
    return 0;
}
```

例题中的 ksm(3, n) 未取模, n 较大时会溢出(仅服务于该题的合法状态枚举)

#pagebreak()

== 最大公约数\_不定方程

=== GCD 与扩展欧几里得 <alg-gcd>

_所属分类: 数论与数学 › 最大公约数\_不定方程_  _复杂度: O(log n)_

*适用问题*

- 求最大公约数 gcd / 最小公倍数 lcm
- 求解不定方程 ax + by = gcd(a, b) 的一组特解

*6.3 GCD（最大公约数）*

*用法*

求解两个整数的最大公约数，辗转相除递归即可。扩展欧几里得（exgcd）可求解不定方程 $a x + b y = gcd(a, b)$ 的一组特解。

*完整模板*

```cpp
int gcd(int a, int b) {
    return b ? gcd(b, a % b) : a;
}

int gcd(int a, int b) {
    if(b == 0) return a;
    else return gcd(b, a % b);
}

int exgcd(int a, int b, int &x, int &y) {
    if (b == 0) {
        x = 1, y = 0;
        return a;
    }
    int g = exgcd(b, a % b, y, x);
    y -= a / b * x;
    return g;
}
```

#pagebreak()

== 与n互质的个数

=== 欧拉函数 <alg-oula-hanshu>

_所属分类: 数论与数学 › 与n互质的个数_  _复杂度: 线性筛 O(n)_

*适用问题*

- 求 φ(n) = \[1,n\] 中与 n 互质的整数个数
- 筛出 1~n 的所有 φ 值

这份笔记涵盖了欧拉函数的定义、通式推导，以及如何将其嵌套进线性筛（欧拉筛）的完整逻辑。

#line(length: 100%)

*📖 欧拉函数 $phi.alt(n)$ 笔记*

*1. 定义与通式*

*定义*：$phi.alt(n)$ 表示 $[1, n]$ 中与 $n$ 互质的整数个数。

*通式*：若 $n = p_1^(k_1) p_2^(k_2) dots p_m^(k_m)$（质因数分解），则：

$ phi.alt(n) = n product_(i=1)^m (1 - 1/p_i) $

#line(length: 100%)

*2. 核心性质推导（用于线性筛）*

线性筛的核心是通过 $n = i times p$（$p$ 为最小质因子）来递推。我们需要根据 $i$ 是否包含 $p$ 分两种情况：

*情况 A：$p divides i$（$p$ 整除 $i$）*

- *前提*：$i$ 已经包含了质因子 $p$。
- *推导*：
  根据通式，$phi.alt(i)$ 已经包含了 $(1 - 1/p)$ 这个项。
  当计算 $phi.alt(i times p)$ 时，由于*质因子种类没有增加*，通式右边的乘积项 $product (1 - 1/p_i)$ 完全不变。
  唯一的改变是前面的系数从 $i$ 变成了 $i times p$。
- *结论*：
  $ phi.alt(i times p) = phi.alt(i) times p $

*情况 B：$p divides.not i$（$p$ 不整除 $i$）*

- *前提*：$p$ 是一个全新的质因子，且 $p$ 是质数，故 $gcd(i, p) = 1$。
- *推导*：
  根据积性函数性质：$phi.alt(i times p) = phi.alt(i) times phi.alt(p)$。
  由于 $p$ 是质数，$phi.alt(p) = p - 1$。
- *结论*：
  $ phi.alt(i times p) = phi.alt(i) times (p - 1) $

#line(length: 100%)

*3. 线性筛欧拉函数标准模板 (C++)*

```cpp
#include <iostream>
#include <vector>

using namespace std;

typedef long long i64;
const int MAXN = 20000005; // 根据题目要求修改

int phi[MAXN];
int primes[1500000]; // 预估素数数量
bool is_not_prime[MAXN];
int cnt = 0;

void precompute_phi(int n) {
    phi[1] = 1; // 1的欧拉函数定义为1
    for (int i = 2; i <= n; ++i) {
        if (!is_not_prime[i]) {
            primes[cnt++] = i;
            phi[i] = i - 1; // 性质：素数 p 的 phi(p) = p - 1
        }
        for (int j = 0; j < cnt; ++j) {
            i64 temp = (i64)i * primes[j];
            if (temp > n) break;
            
            is_not_prime[temp] = true;
            
            if (i % primes[j] == 0) {
                // 情况 A：primes[j] 是 i 的老面孔 (p | i)
                // 质因子种类没变，只增加数值倍数
                phi[temp] = phi[i] * primes[j];
                break; // 线性筛精髓：找到最小质因子后停止
            } else {
                // 情况 B：primes[j] 是新质因子 (p 不整除 i)
                // 利用积性函数性质 phi(i*p) = phi(i) * (p-1)
                phi[temp] = phi[i] * (primes[j] - 1);
            }
        }
    }
}

int main() {
    // 快速 I/O
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    precompute_phi(20000000);

    int T, x;
    if (!(cin >> T)) return 0;
    while (T--) {
        cin >> x;
        cout << phi[x] << "\n";
    }
    return 0;
}
```

#line(length: 100%)

*4. 记忆要点总结*

+ *初始化*：`phi[1] = 1`。
+ *遇到素数*：`phi[i] = i - 1`。
+ *内层标记*：
  - *能整除*：说明质因子已经在地盘里了，直接*乘 $p$*。
  - *不能整除*：说明来了个新质因子，要*乘 $(p-1)$*。

这两个公式的推导，本质上是观察*“质因子的种类”*有没有发生变化。我们再次祭出欧拉函数的通式（也就是你图片里的那个）：

$ phi.alt(n) = n dot product_(p|n) (1 - 1/p) $

这个公式告诉我们：$phi.alt(n)$ 的值由 $n$ 本身 和 $n$ 包含的所有不同质因子 共同决定。公式一：当 $i (mod p) = 0$ 时这种情况意味着 $p$ 已经是 $i$ 的质因子了。分析 $phi.alt(i)$：

$ phi.alt(i) = i dot (1 - 1/p_1) dot (1 - 1/p_2) dots dot (1 - 1/bold(p)) $

分析 $phi.alt(i dot p)$：当我们把 $i$ 乘以 $p$ 得到新数时，新数的质因子集合与 $i$ 的完全一样（因为 $p$ 本来就在里面）。所以，公式右边的连乘部分（那些括号）一个都不会变。

$ phi.alt(i dot p) = (i dot p) dot underbrace((1 - 1/p_1) dots dot (1 - 1/p), text("这部分就是 ") phi.alt(i)/i) $

得出结论：

$ phi.alt(i dot p) = (i dot p) dot phi.alt(i)/i = bold(phi.alt(i) dot p) $

直观理解：质因子种类没变，“打折比例”就没变，数值翻了 $p$ 倍，结果自然也翻 $p$ 倍。公式二：当 $i (mod p) != 0$ 时这种情况意味着 $p$ 是一个全新的质因子，它不在 $i$ 原有的质因子列表里。分析 $phi.alt(i)$：

$ phi.alt(i) = i dot product_(p_"old"|i) (1 - 1/p_"old") $

分析 $phi.alt(i dot p)$：因为 $p$ 是新来的，根据通式，我们不仅要把前面的系数乘以 $p$，还要在后面多乘一个新括号 $(1 - 1/p)$。

$ phi.alt(i dot p) = (i dot p) dot [product_(p_"old"|i) (1 - 1/p_"old")] dot bold((1 - 1/p)) $

化简：中间那一团就是 $phi.alt(i)$，所以：

$ phi.alt(i dot p) = phi.alt(i) dot p dot (1 - 1/p) $

把 $p$ 乘进括号里：$p times (1 - 1/p) = p - 1$。

$ bold(phi.alt(i dot p) = phi.alt(i) dot (p - 1)) $
#pagebreak()

== 筛素数

=== 欧拉筛(线性筛) <alg-xianxing>

_所属分类: 数论与数学 › 筛素数_  _复杂度: O(n)_

*适用问题*

- 求 \[1,n\] 内所有素数(每个合数只被最小质因子筛掉一次)

*7.1 欧拉筛（线性筛）*

*用法*

欧拉筛（线性筛）用于在 $cal(O)(n)$ 时间内求出 $[1, n]$ 范围内的所有素数，每个合数只被其最小质因子筛掉一次，避免了埃氏筛的重复标记。

*实现步骤*

+ 维护 `is_not_prime[]` 标记合数，`primes` 列表存储素数
+ 遍历 $i = 2 dots n$：
  - 若 $i$ 未被标记，则为素数，加入 `primes`
  - 遍历 `primes`，将 $i times primes[j]$ 标记为合数
  - 若 $i mod primes[j] = 0$，则 *break*
+ 最终 `primes` 列表即为 $[1, n]$ 内所有素数

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 MAXN = 1e7 + 5; //需要的素数的范围 自行修改
vector<i64> primes; //求得的素数数组
bool is_not_prime[MAXN]; //不是素数的判断

void euler_sieve(int n) {
    is_not_prime[0] = is_not_prime[1] = true;//标记0和1
    for (int i = 2; i <= n; i++) {
        if (!is_not_prime[i]) {
            primes.push_back(i);
        }
        for (int p : primes) {
            if ((long long)i * p > n) break;
            is_not_prime[i * p] = true;
            if (i % p == 0) break; //合数 = 最小质数 * 一个数 保证当前是最小质数 才能保证合数的唯一性
        }
    }
}
```

#pagebreak()

=== 线性筛因数 <alg-spf>

_所属分类: 数论与数学 › 筛素数_  _复杂度: 筛 O(n) / 分解质因数 O(log n)_

*适用问题*

- 筛出 1~n 每个数的最小质因子 spf
- O(log n) 分解质因数
- 由质因数分解求因数个数/约数和

*完整模板*

```cpp
#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const i64 MAXN = 1e7 + 5; //需要的范围 自行修改
vector<i64> primes; //求得的素数数组
bool is_not_prime[MAXN]; //不是素数的判断
i64 spf[MAXN]; //每个数的最小质因子

void euler_sieve(int n) {
    is_not_prime[0] = is_not_prime[1] = true; //标记0和1
    spf[1] = 1;
    for (int i = 2; i <= n; i++) {
        if (!is_not_prime[i]) {
            primes.push_back(i);
            spf[i] = i; //质数的最小质因子是自己
        }
        for (int p : primes) {
            if ((long long)i * p > n) break;
            is_not_prime[i * p] = true;
            spf[i * p] = p;
            if (i % p == 0) break; //合数 = 最小质数 * 一个数 保证当前是最小质数 才能保证合数的唯一性
        }
    }
}

// 分解质因数 O(log n)
vector<pair<i64, i64>> factorize(i64 x) {
    vector<pair<i64, i64>> res;
    while (x > 1) {
        i64 p = spf[x];
        i64 cnt = 0;
        while (x % p == 0) {
            x /= p;
            cnt++;
        }
        res.push_back({p, cnt});
    }
    return res;
}
```

*注意*

- 若只需素数表, 用 线性筛;需分解质因数/求因数个数时用本板子

#pagebreak()

== 等比数列求和

=== 等比数列求和 <alg-dengbi>

_所属分类: 数论与数学 › 等比数列求和_  _复杂度: O(1)(公式)或 O(log n)(结合快速幂)_

*适用问题*

- 等比数列前 n 项和、无穷等比级数(|q|\<1)

*6.2 等比数列求和公式笔记*

*1. 基本公式*

设等比数列首项为 $a_1$，公比为 $q$，项数为 $n$。

当 $q != 1$ 时：

$ S_n = (a_1 (1 - q^n))/(1 - q) $

当 $q = 1$ 时：

$ S_n = n a_1 $

*2. 公式推导（错位相减法）*

$ S_n = a_1 + a_1 q + a_1 q^2 + dots.c + a_1 q^(n-1) $

$ q S_n = a_1 q + a_1 q^2 + dots.c + a_1 q^(n-1) + a_1 q^n $

两式相减：

$ S_n - q S_n = a_1 - a_1 q^n $

$ (1 - q) S_n = a_1 (1 - q^n) $

$ therefore S_n = (a_1 (1 - q^n))/(1 - q) $

*3. 无穷等比数列（|q|\<1）*

$ S = a_1/(1 - q) $

*4. 常用变形*

#table(
  columns: 2,
  stroke: none,
  [已知条件], [公式],
  [已知 $a_1$、$a_n$], [$S_n = (a_1 - a_n q)/(1-q)$],
  [已知 $a_1$、$a_n$], [$S_n = (a_n q - a_1)/(q-1)$],
)

其中 $a_n = a_1 q^(n-1)$。

#pagebreak()

== 整除取整技巧

=== 向上取整 <alg-xiangshang>

_所属分类: 数论与数学 › 整除取整技巧_  _复杂度: O(1)_

*适用问题*

- 求 ⌈a/b⌉, 避免浮点数误差
- 二进制数组求和技巧: 每个数 /2 向下取整的和 = (数组总和 - 奇数的个数) / 2

```cpp
⌈a / b⌉ = (a + b - 1) / b

// 每个数/2向下取整的和 = (数组总和 - 奇数个数) / 2
sum = (total - odd_cnt) / 2
```
